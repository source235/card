<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = ""; //viết thường
const TOKEN = "rZAatA3eqoS81Rrhl4PTI0PzAMpxoLIxot3Y8e56S2un6UKTeI";
const SIGNATIRE = "1a2fbd2cfc0ef73f3409f8c366d127d37f695c143719941447445d7f085b3414";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/CARD/ub2Bzz9O";