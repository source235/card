<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = ""; //viết thường
const TOKEN = "b2zyq7ISnVk8V2dzYGlfrhOJSfwxRcNw2Pf0Shue2RISWE91Fw";
const SIGNATIRE = "1bdda9c7fd20a61f47e44a2737a13839debf57a392a29278b073c9e8010b2b9f";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/CARD/h9xhQIAS";