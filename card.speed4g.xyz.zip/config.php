<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = ""; //viết thường
const TOKEN = "DJ1DrtgdGOqVWhRIFpFDTDkIeDS4Dl0BiyNfGeH8IEMQfoYErq";
const SIGNATIRE = "31ebbf80ba0c4b5413bb8ec84b009a6cb8d662fff0ae231b043734a12499083f";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/CARD/K4o9LcPc";