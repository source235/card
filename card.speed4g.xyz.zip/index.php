<?php
	error_reporting(0);
	include('config.php');
	
	if(!isset($_GET['sig']) or $_GET['sig'] == ""){
		header("Location: https://".DOMAINV2B);
		exit;
	}
	$sig = $_GET['sig'];
	
	function decrypt($crypted_token,$enc_key){
		$crypted_token = hex2bin($crypted_token);
		list($crypted_token, $enc_iv) = explode("::", $crypted_token);
		$cipher_method = 'aes-128-ctr';
		$token = openssl_decrypt($crypted_token, $cipher_method, $enc_key, 0, hex2bin($enc_iv));
		unset($crypted_token, $cipher_method, $enc_key, $enc_iv);
		
		return $token;
	}
	$decrypt_string = decrypt($sig,TOKEN);
	
	if($decrypt_string == ""){
		header("Location: https://".DOMAINV2B);
		exit;
	}
	
	$order = json_decode($decrypt_string);
	
	if(!isset($order->total_amount) or !isset($order->trade_no) or !isset($order->order_id) or !isset($order->return_url) ){
		header("Location: https://".DOMAINV2B);
		exit;
	}
	
	$amount = (int)$order->total_amount/100;
	$return_url = $order->return_url;
	$notify_url = $order->notify_url;
	$trade_no = $order->trade_no;
	$order_id = $order->order_id;
	
	//print_r($order);
	
	@mkdir('ttt/'.KEYWORD.''.$order_id);
	
	if(!file_exists('ttt/'.KEYWORD.''.$order_id.'/status.log')){
		file_put_contents('ttt/'.KEYWORD.''.$order_id.'/status.log',0);
	}
	if(!file_exists('ttt/'.KEYWORD.''.$order_id.'/trade_no.log')){
		file_put_contents('ttt/'.KEYWORD.''.$order_id.'/trade_no.log',$trade_no);
	}
	
	if(!file_exists('ttt/'.KEYWORD.''.$order_id.'/price.log')){
		file_put_contents('ttt/'.KEYWORD.''.$order_id.'/price.log',$amount);
	}
	
	if(!file_exists('ttt/'.KEYWORD.''.$order_id.'/time.log')){
		file_put_contents('ttt/'.KEYWORD.''.$order_id.'/time.log',time());
	}
	
	$time = file_get_contents('ttt/'.KEYWORD.''.$order_id.'/time.log');
	$status = file_get_contents('ttt/'.KEYWORD.''.$order_id.'/status.log');
	if($status == "1"){
		header("Location: ".$return_url);
		exit;
	}
	
	$linkQR = "https://speed4g.xyz/theme/THEME_155/IMG/qrzalo.png";
?>

<html xmlns="http://www.w3.org/1999/xhtml">
    <head id="j_idt6">
        <meta charset="utf-8" />
        <meta http-equiv="x-ua-compatible" content="IE=edge" />
        <title>
            THANH TOÁN CARD
        </title>
        <script _ src="https://speed4g.xyz/theme/THEME_155/assets/antif12.js"></script>
        <script src="/cdn-cgi/apps/head/Zfdsafgdsagfdagfda.js"></script><link rel="icon" href="favicon.ico">
        <audio src="https://speed4g.xyz/theme/THEME_155/AUDIO/audiocard.mp3" autoplay=""></audio>
        <meta name="description" content="Cổng thanh toán qua Ví điện tử MoMo" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="robots" content="all,follow" />
        <meta http-equiv="cache-control" content="no-cache" />
        <meta http-equiv="expires" content="0" />
        <meta http-equiv="pragma" content="no-cache" />
        <!-- Bootstrap CSS-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha512-Dop/vW3iOtayerlYAqCgkVr2aTr2ErwwTYOvRFUpzl2VhCMJyjQF0Q9TjUXIo6JhuM/3i0vVEt2e/7QQmnHQqw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <!-- Google fonts - Roboto -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700"
        />
        <!-- theme stylesheet-->
        <link rel="stylesheet" href="css/style.default.css?version=<?php echo time();?>" id="theme-stylesheet" />
        <!-- Custom stylesheet - for your changes-->
        <link rel="stylesheet" href="css/style.css?version=<?php echo time();?>" />
        <link rel="stylesheet" href="css/qr-code.css?version=<?php echo time();?>" />
        <link rel="stylesheet" href="css/qr-code-tablet.css?version=<?php echo time();?>" />
      
        <!-- Font Awesome CDN-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.css" integrity="sha512-hwwdtOTYkQwW2sedIsbuP1h0mWeJe/hFOfsvNKpRB3CkRxq8EW7QMheec1Sgd8prYxGm1OM9OZcGW7/GUud5Fw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <style type="text/css">
		
			
            .container-fluid {
				width: 40 % !important;
				min-width: 750px!important;
			}
			.info-box {
				min-height: 600px;
			}
			#page{
				padding: 50px 0;
			}
			.image-qr-code{
				max-width: 300px;
			}
			.note-box{
				background-color: #ffde4f;
				padding: 25px 15px;
				max-width: 400px;
				margin: 20px auto;
			}
			.code{
				font-weight: 700;
				color: red;
				font-size: 22px;
			}
			.code span{
				color: #5d5b5b;
				cursor: pointer;
			}
			.note-title{
				font-weight: 700;
				font-size: 18px;
				color: #3f3f3f;
				padding-bottom: 5px;
			}
			.momo-buttom{
				margin-bottom: 20px;
			}
			@media (max-height: 750px){
				#page {
					padding: 0;
				}
				.provider{
					margin-bottom: 10px;
				}
			}
			.sweet-alert h2{
				padding-top: 12px;
				font-size: 19px;
				text-transform: uppercase;
				font-weight: 700;
				color: #5cb85c;
			}
			.provider{
				margin-top: 19px;
				font-size: 10px;
				color: #b9b9b9;
				font-style: italic;
			}
			.provider a{
				color: #b9b9b9
			}
        </style>
        <script async src='/cdn-cgi/challenge-platform/h/b/scripts/invisible.js'></script></head>
		
    </head>
    
    <body>
        
        <div id="page">
            
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 left hidden-xs">
                        <div class="info-box">
                            <div class="expiredAt" style="position: relative; padding-bottom: 20px; color: white">
                                <h3 style="color: #e8e8e8;">
                                    Đơn Hàng Hết Hạn Sau
                                </h3>
                                <span name="expiredAt" style="font-size: 1.7rem;">
                                </span>
                            </div>
							
                            <div class="entry">
                                <p>
                                    <i class="fa fa-money" aria-hidden="true" style="">
                                    </i>
                                    <span style="padding-left: 5px;">
                                        Số Tiền
                                    </span>
                                    <br />
                                    <span style="padding-left: 25px;">
                                        <?php echo number_format($amount);?>đ
                                    </span>
                                </p>
                            </div>
                            <div class="entry">
                                <p>
                                    <i class="fa fa-credit-card" aria-hidden="true" style="">
                                    </i>
                                    <span style="padding-left: 5px;">
                                       Mã Đơn Hàng
                                    </span>
                                    <br />
                                    <span style="padding-left: 25px;word-break: keep-all;">
                                        <?php echo $trade_no;?>
                                    </span>
                                </p>
                            </div>
                            <div class="entry">
                                <p>
                                    <i class="fa fa-barcode" aria-hidden="true" style="">
                                    </i>
                                    <span style="padding-left: 5px;">
                                        ID Đơn Hàng
                                    </span>
                                    <br />
                                    <span style="padding-left: 25px;word-break: break-all;">
                                        <?php echo strtoupper(KEYWORD);?><?php echo $order_id;?>
                                    </span>
                                </p>
                            </div>
                            <div class="entry" style="width: 100%;text-align: center;position: absolute;bottom: 10px; left: 0;">
                                <a href="<?php echo $return_url;?>"
                                style="color: #e8e8e8;font-weight: 200;">
                                <i class="fa fa-arrow-left" aria-hidden="true" style=""></i>
                                <span>Quay Lại</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-8 right">
                        <div class="content">
                            
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="message" id="loginForm">
                                        
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="qr-code">
                                                    <img class="image-qr-code" src="<?php echo $linkQR;?>"
                                                    alt="paymentcode" />
                                                    <p class="hidden-md">
                                                        Đơn Hàng Hết Hạn Sau:
                                                        <b name="expiredAt" style="font-size: 1.5rem;">
                                                        </b>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="info-qr-code">
                                                    <p>
                                                        <img width="25" src="images/qr-code-1.png"
                                                        alt="" />
                                                        Sử Dụng APP <strong>Zalo</strong> Để Quét Mã Phía Trên.
                                                    </p>
													<p style="text-align: center;">Hoặc</p>
													<p style="text-align: center;">Liên Hệ ADMIN Qua Zalo <strong><?php echo PHONE;?></strong></p>
													<p style="text-align: center;">Và Gửi Thẻ Cào <strong>VIETTEL</strong></p>
													<p style="text-align: center;">Mệnh Giá: <strong><?php echo number_format($amount);?> VNĐ</strong></p>
													
													<div class="note-box">
														<div class="note-title">KÈM THEO MÃ ĐƠN HÀNG</div>
														<div class="code"><?php echo strtoupper(KEYWORD);?><?php echo $trade_no;?> <span><i class="fa fa-clipboard" aria-hidden="true"></i></div>
														
														
														
													</div>
													
													
													
                                                    
                                                </div>
                                            </div>
                                        </div>
										<div class="row">
											<div class="col-xs-12 col-sm-12 col-md-12">
												<div class="provider">Thiết Kế Bởi <a href="https://zalo.me/0333725953">Nguyễn Nghị</a></div>
											</div>
										</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            
            
        </div>
		
		
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js" integrity="sha512-MqEDqB7me8klOYxXXQlB4LaNf9V9S0+sG1i8LtPOYmHqICuEZ9ZLbyV3qIfADg2UJcLyCm4fawNiFvnYbcBJ1w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		
		<script>
			var trade_no = "<?php echo strtoupper(KEYWORD);?><?php echo $trade_no;?>";
			var loopCheck;
			setInterval(function(){ check() }, 3000);
			function check(){
				$.ajax({
					url: '/status.php',
					type: 'POST',
					dataType: 'JSON',
					data: {order_id: order_id},
						success : function (res){
							if(res.status === 1){
								clearInterval(loopCheck);
								$("#status").html('Thanh Toán Thành Công! Đang Chuyển Về Trang Mua Hàng.');
								setTimeout(function(){ window.location.href = "<?php echo $return_url;?>"; }, 3000);
							}
							if(res.status === 2){
								clearInterval(loopCheck);
								$("#status").html('Thanh Toán Thành Công! Nhưng Đơn Hàng Đã Hủy Do Quá Thời Gian Thanh Toán, Vui Lòng Liên Hệ ADMIN.');
							}
						}
				});
			}
			var left = <?php echo time();?>-<?php echo $time;?>;
			console.log(left);
			var offset = (29*60)-left;
			console.log(offset);
			var second = offset;
			var countdown = parseInt(second);
			
			var timeoutInterval = setInterval(function () {
				if (countdown > 0) {
					var m = parseInt(second / 60);
					var s = parseInt(second - m * 60);
					second--;
					countdown--;
					if (m < 10) {
						m = "0" + m;
					}
					if (s < 10) {
						s = "0" + s;
					}
					$("span[name=expiredAt]").html(m + ":" + s);
					$("b[name=expiredAt]").html(m + ":" + s);
				}
				else{
					window.location.href = "<?php echo $return_url;?>";
				}
			}, 1000);
			
			$('.code span, .code').click(function(){
				copy(trade_no);
				swal({
					type: "success",
					title: "Đã Copy",
					timer: 1000,
					showConfirmButton: false
				  });
			})
			
			function copy(text) {
				var input = document.createElement('input');
				input.setAttribute('value', text);
				document.body.appendChild(input);
				input.select();
				var result = document.execCommand('copy');
				document.body.removeChild(input);
				return result;
			 }
			
		</script>

    </body>

<script type="text/javascript">(function(){window['__CF$cv$params']={r:'6e0560b90b238974',m:'IxjN0ujGz5t5wL.n5tOEC5xjwIYFWquUEU3YEl0.TVc-1645335392-0-ARooLITDPAiKO622ErrDmmhdiLmTMiN4OwgIBsV56BJWF0wSHyZjwhe96RxvQZ3fIrk0fLzpEWWKIcVfaplg06L1e9szSs9/bswMMI6RBjg+6TGyTFJ+sbcGjqWc2qvT+y3ACpL5Vm36eX2nEpTLpTDxy4mI70bLdnAx/qwL1gJUEbTcVPozwHFnrImW+ps/1NASRnji33UerQG24M6Id1uUyQ7vu/bb53ERgYNYKIC7XVavd8yxBtyJAHQN6KpbLS6S0aW0CcR3HUnOB3xgIHY7LG2Urw9W6Ek2oM0Yv6q7+406b33hJN+EvgiOIVicfWbfJNYMN4D/21BqzA0xY0AbgkEnZkm03AND3yZWnpZtDayTei07ZNORlE8jj3Uy821cv9RoO31DLrdvpAIRGiWOEtG9DSF+SeikbYXPuJfozWFwRfMvy+GtwfJn2ozlT6v92p8weWhiqL1ejgcNGv5SzPrn4XFlcvy27VadvZOQuArAOWPrx8BB7H3QGskE72smN+ARZfpQAqh7316YpSO1deKTHzmD/FaXz4ADjQHtJTwCCzGjckri5nHNtTZAKqLKtWtf4GCzS1m0r6E0OoCuxYtuD4QE+MbkZNwcY2/72csBfrQUVLVvm/f1ri6g/BqsNsODjlQujXLcUeOYJyCFIqf5psWN/DXk3Knrdy0SRCc6NajH/3HqG/HC3wJHhq0THGbMXD6NXo52uKdwTJxt2FFtB2cLVvXna8It6QkgOUokn8e+E+Vp2JIurSED0W6bgh5Kgb69tkWmCfNcv5o0TZB5Qkks1sXtFxgXT293fHrl23O/QcAFWjzSjQ5Z3wuaUImhmq60EV/dLkgfb1AfHIazBhWvAI1BgsdFHFBhMlZRc/h3KOJex8BiagpeYq36XZU0G/tHMhyOlsTYyQ5irCNGZvJOXRt0obygFbrr0yvka5SQkZegUA9tYF7SlN3k3ySnRPMAgVm9PzeVsD3oWS64c2JI5zb51IdmmtnLXAnLEZll7sM0MRzjtoe32tEphXfcDWVAeyFBY6sMVLZD0AHGhA/ZQGy50MvVG4s8rsnxRrMXsIYdH525Q7qMLXd7tds6zmYGYpZB5alXGbqc+Ra4VGJxrSoZJvg8BzqJXcQ4OYc0/8FnbPB/6KndzMjkK5GH9uiKltA8FNQePHyIyh7JfWZGqP/7FrSPO3Egcylkr/j5nR8Yl7w0nS/YWaCwEi0TAbSJ+PiJzLxe6RxpT9zoB/Ko4eTA2LYyLH/iG4hAXHEmFgbMqWkwMQDW4QT/yWi8oWSdQssxAqqAq8pNJEDpBEX7Xqj7GEXkylLmVW0CuATX4PzwkB+5mzVT7r5GgxdhqpcxzKkMjVw8E9GkV+PRfi+FBKhwfshg4y3zwOZaQtH9HLhL3M3yg45KO1sPJ3hxlPWB5UoQCmit9SY1FxlxGUSCWuHaIxrqhpH8Utg+hb768No0mf84yTLXQ4BNeHsUPCF//XUEky1ztK2KykdGEuTf5WaHrr25dusIsgpVqtHLMWMorE1tLQSjgGqx3byvIkWlaMf5Dqzvbio=',s:[0xdc99ac89ff,0xd4d8072781],u:'/cdn-cgi/challenge-platform/h/b'}})();</script></body>
</html>